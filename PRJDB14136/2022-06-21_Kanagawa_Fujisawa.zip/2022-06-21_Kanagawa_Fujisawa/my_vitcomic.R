rm(list = ls())
#' - https://github.com/haruosuz/bioinfo/blob/master/2022/CaseStudy.md#2022-12-28
#' - http://vitcomic.org/
#' - https://github.com/h-mori/vitcomic2
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5861490/
# Load the R packages
library(tidyverse)

# Loading Data into R
mydir <- "./result/VITCOMIC_result/"
mydir <- "./VITCOMIC_result"
( myfile <- list.files(path=mydir, pattern=".genus.txt", full.names=TRUE) )
d <- read.delim(file=myfile, stringsAsFactors=FALSE, header = FALSE) # na.strings="-", quote="", check.names=FALSE

# Exploring and Transforming Dataframes
dim(d)
colnames(d) <- c("genus", "phylum_class", "Nreads")
sum(d$Nreads)
x <- summarise(group_by(d, `phylum_class`), sum.Nreads = sum(Nreads))
x <- mutate(x, pct.sum.Nreads = 100 * x$sum.Nreads / sum(x$sum.Nreads) ) %>% arrange(desc(sum.Nreads))
x
d$pct.Nreads <- 100 * d$Nreads / sum(d$Nreads)
d <- d[order(d[,3], decreasing=TRUE),]
write.table(d, file=paste0("R.VITCOMIC.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
#sessionInfo()
Sys.time()




