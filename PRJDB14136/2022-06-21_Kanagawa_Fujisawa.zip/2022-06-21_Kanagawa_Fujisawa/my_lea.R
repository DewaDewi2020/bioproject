rm(list = ls())
# Load the R packages
library(tidyverse)
# Loading Data into R
mydir <- "." 
( myfile <- list.files(path=mydir, pattern=".csv$", full.names=TRUE) ) #20230315121037cd1765c62a2deec6f7678e6018b219ad.csv
d <- read_csv(myfile); dim(d); d <- d[,-1]; d <- as.data.frame(t(d)); d <- d %>% arrange(desc(V1))
write.table(d, file=paste0("R.LEA.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
sessionInfo()
Sys.time()


